import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-call',
  templateUrl: './video-call.page.html',
  styleUrls: ['./video-call.page.scss'],
  standalone : false
})
export class VideoCallPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
