import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incoming-call',
  templateUrl: './incoming-call.page.html',
  styleUrls: ['./incoming-call.page.scss'],
  standalone : false
})
export class IncomingCallPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
