export interface User {
    uid: string;
    email: string;
    nombre: string;
    apellido: string;
    telefono: string;
  }