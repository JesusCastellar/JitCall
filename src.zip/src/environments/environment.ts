// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDMs1k5KrRoBxeB3VRV6smRXk6BWZjpIYk",
  authDomain: "jitcall-b72ec.firebaseapp.com",
  projectId: "jitcall-b72ec",
  storageBucket: "jitcall-b72ec.firebasestorage.app",
  messagingSenderId: "143489396645",
  appId: "1:143489396645:web:c0589cbc9a4ef07e65c24c",
  measurementId: "G-3VS63P1SYS"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
